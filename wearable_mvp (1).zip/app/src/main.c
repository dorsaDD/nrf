#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

/* from other compilation units */
void start_threads(void);
int radio_init(void);

void main(void) {
    LOG_INF("boot");
    int err = radio_init();
    if (err) {
        LOG_ERR("radio init failed (%d)", err);
    }
    start_threads();
    while (1) {
        /* main stays idle; system can enter sleep states */
        k_sleep(K_SECONDS(30));
    }
}
