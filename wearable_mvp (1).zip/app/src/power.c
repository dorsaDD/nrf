#include <zephyr/kernel.h>
#include <zephyr/pm/pm.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(power, LOG_LEVEL_INF);

/* Placeholder for future power helpers:
   - device runtime suspend/resume
   - custom residency policy tweaks
   - RAM retention configuration for deep sleep
*/
void power_init(void) {
    LOG_INF("power: init (placeholder)");
}
