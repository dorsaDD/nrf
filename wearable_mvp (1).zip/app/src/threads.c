#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(threads, LOG_LEVEL_INF);

/* Stacks & priorities */
#define STACKSZ 1024
#define PRIO_RADIO   2
#define PRIO_SENSOR  3
#define PRIO_TIMER   4

K_THREAD_STACK_DEFINE(stack_radio,  STACKSZ);
K_THREAD_STACK_DEFINE(stack_sensor, STACKSZ);
K_THREAD_STACK_DEFINE(stack_timer,  STACKSZ);

static struct k_thread t_radio, t_sensor, t_timer;

/* Simple queue for uplink triggers */
K_MSGQ_DEFINE(msgq_uplink, sizeof(uint32_t), 16, 4);

static void radio_thread(void *a, void *b, void *c) {
    LOG_INF("[radio] alive");
    while (1) {
        /* later: wait on msgq_uplink to send BLE notifications */
        k_msleep(1000);
        LOG_INF("[radio] idle (sleep candidate)");
        k_sleep(K_SECONDS(5));
    }
}

static void sensor_thread(void *a, void *b, void *c) {
    LOG_INF("[sensor] alive");
    while (1) {
        /* later: block on accelerometer GPIO interrupt semaphore */
        k_msleep(500);
        LOG_INF("[sensor] idle (sleep candidate)");
        k_sleep(K_SECONDS(5));
    }
}

static void timer_thread(void *a, void *b, void *c) {
    LOG_INF("[timer] alive");
    while (1) {
        LOG_INF("[timer] wake event -> would trigger measurements");
        uint32_t tick = k_uptime_get_32();
        (void)k_msgq_put(&msgq_uplink, &tick, K_NO_WAIT);
        k_sleep(K_SECONDS(10)); /* change to K_HOURS(1) later */
    }
}

void start_threads(void) {
    k_thread_create(&t_radio,  stack_radio,  STACKSZ, radio_thread,  NULL, NULL, NULL, PRIO_RADIO,  0, K_NO_WAIT);
    k_thread_create(&t_sensor, stack_sensor, STACKSZ, sensor_thread, NULL, NULL, NULL, PRIO_SENSOR, 0, K_NO_WAIT);
    k_thread_create(&t_timer,  stack_timer,  STACKSZ, timer_thread,  NULL, NULL, NULL, PRIO_TIMER,  0, K_NO_WAIT);
    LOG_INF("[threads] spawned");
}
